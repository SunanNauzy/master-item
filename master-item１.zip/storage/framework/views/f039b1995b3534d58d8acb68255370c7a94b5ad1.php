<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800">Item</h1>
  

  <a href="<?php echo e(route('item.create')); ?>" class="btn btn-primary mb-4">Add A New Item</a>

  <button type="button" class="btn btn-primary mb-4" data-toggle="modal" data-target="#importExcel">
    IMPORT EXCEL
</button>

    <!-- Import Excel -->
    <div class="modal fade" id="importExcel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <form method="post" action="<?php echo e(route('item.import_excel')); ?>" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
                    </div>
                    <div class="modal-body">

                        <?php echo e(csrf_field()); ?>


                        <label>Pilih file excel</label>
                        <div class="form-group">
                            <input type="file" name="file" required="required">
                        </div>
                        <a href="<?php echo e(asset('template/template.xlsx')); ?>" class="float-right" download>Download Template</a>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Import</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Item Datatable</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover ajaxTable datatable datatable-Transaction" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Id</th>
              
              <th>jumlah pengajuan</th>
              <th>tanggal</th>
              <th>approval status</th>
              <th>User</th>
              <th>Unit</th>
              <th>Tipe</th>
              <th>Jenis Transaksi</th>
              <th>Bidang</th>
              <th>Kelompok</th>
              <th>Jenis</th>
              <th>Type</th>
              <th>Bulan</th>
              <th>Kode Barang</th>
              <th>actions</th>
            </tr>
          </thead>
          
          <tbody></tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
  $('#dataTable').dataTable({
  processing:true,
  serverSide:true,
  ajax:"<?php echo e(route('item.all')); ?>",
    columns:[
      {data:'id'},
    //   {data:'name'},
      {data:'qty'},
      {data:'input_date'},
      {data:'approval_status'},
      {data:'user'},
      {data:'unit'},
      {data:'tipe'},
      {data:'jenis_transaksi'},
      {data:'bidang'},
      {data:'kelompok'},
      {data:'jenis'},
      {data:'type'},
      {data:'bulan'},
      {data:'kode_barang'},
      {data:'actions',orderable:false,searchable:false},
    ]
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-item\resources\views/item/index.blade.php ENDPATH**/ ?>