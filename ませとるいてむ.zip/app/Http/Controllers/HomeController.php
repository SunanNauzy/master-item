<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Item;

class HomeController extends Controller
{
  public function index()
  {
//     $item = Item::latest()->take(4)->get();
//     return view('item.index')->with([
//       'item' => $item
//     ]);
//   }

//   public function show(Item $item)
//   {
//     return view('item.show', compact('item'));
//   }
}}
