<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

  <!-- Sidebar - Brand -->
  <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('item.index')); ?>">
    <div class="sidebar-brand-text mx-2">item</div>
  </a>

  <!-- Divider -->
  <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e(request()->segment(2) == 'dashboard' ? 'active': ''); ?>">
      <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
    </li>

  <li class="nav-item <?php echo e(request()->segment(2) == '' ? 'active': ''); ?>">
    <a class="nav-link" href="<?php echo e(route('item.index')); ?>">
      <i class="fas fa-fw fa-h-square"></i>
      <span>Home</span></a>
  </li>

  <!-- Divider -->
  <hr class="sidebar-divider">


  <!-- Heading -->
  <div class="sidebar-heading">
    Admin Information
  </div>

  <!-- Nav Item - Pages Collapse Menu -->
  

  <!-- Nav Item - Pages Collapse Menu -->
  <li class="nav-item">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
      <i class="fas fa-fw fa-bus-alt"></i>
      <span>Item</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
      <div class="bg-white py-2 collapse-inner rounded">
        <h6 class="collapse-header">Item Bread:</h6>
        <a class="collapse-item" href="<?php echo e(route('item.index')); ?>">All Item</a>
        <a class="collapse-item" href="<?php echo e(route('item.create')); ?>">Add a new Item</a>
      </div>
    </div>
  </li>

  <!-- Nav Item - Utilities Collapse Menu -->
  


  


  


</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\xampp\htdocs\master-item\resources\views/inc/admin/sidebar.blade.php ENDPATH**/ ?>