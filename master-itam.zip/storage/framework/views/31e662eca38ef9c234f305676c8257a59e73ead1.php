<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Updating item</h1>
  <form action="<?php echo e(route('item.update',['id'=>$item->id])); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div class="row">

      <div class="col-lg-6">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Enter the item details</h6>
          </div>
          <div class="card-body">
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                <?php echo e(implode('', $errors->all(':message'))); ?>

              </div>
            <?php endif; ?>
              <div class="form-group">
                <label for="">Name of the PIC</label>
                <input type="text" value="<?php echo e($item->name); ?>" class="form-control form-control-user" <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="name" placeholder="Enter name ..."   autocomplete="name" autofocus>
                  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Bulan</label>
                <input type="text"  value="<?php echo e($item->bulan); ?>" class="form-control form-control-user" <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="bulan" placeholder="bulan"   >
                <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Tanggal</label>
                <input type="date"  value="<?php echo e($item->input_date); ?>" class="form-control form-control-user" <?php $__errorArgs = ['input_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="input_date" placeholder="Tanggal"   >
                <?php $__errorArgs = ['input_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Approval Status</label>
                <input type="text"  value="<?php echo e($item->approval_status); ?>" class="form-control form-control-user" <?php $__errorArgs = ['approval_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="approval_status" placeholder="Approval Status"   >
                  <?php $__errorArgs = ['approval_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Jumlah Pengajuan</label>
                <input type="number"  value="<?php echo e($item->qty); ?>" class="form-control form-control-user" <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="qty" placeholder="Jumlah Pengajuan ..."  >
                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              

              <div class="form-group">
                <label for="selectOption">User</label>
                <select name="user" class="form-control" id="selectOption">
                    <option value="">-- Select User --</option>
                    <?php $__currentLoopData = $userf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->userf_number); ?>" <?php echo e($item->user == $data->userf_number ? 'selected' : ''); ?>>
                            <?php echo e($data->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="inputAutoFill">Unit</label>
                <input type="text" value="<?php echo e($item->unit); ?>" class="form-control" id="inputAutoFill" name="unit" readonly>
            </div>

            <hr>

          <div class="card-body">
            

          </div>
        </div>
      </div>



    </div>

          <div class="col-lg-6">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Enter The Item Details</h6>
          </div>
          <div class="card-body">

            <div class="form-group">
                <label for="">Tipe</label>
                
                <select value="<?php echo e(old('tipe')); ?>" name="tipe" class="form-control form-control-user" <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  placeholder="Tipe"  >
                    <option value="">-- Select Tipe --</option>
                    <option value="Barang" <?php echo e($item->tipe == 'Barang' ? 'selected' : ''); ?>>Barang</option>
                    <option value="Jasa" <?php echo e($item->tipe == 'Jasa' ? 'selected' : ''); ?>>Jasa</option>
                </select>
                                <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Jenis Transaksi</label>
                <input type="text"  value="<?php echo e($item->jenis_transaksi); ?>" class="form-control form-control-user" <?php $__errorArgs = ['jenis_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="jenis_transaksi" placeholder="jenis_transaksi"   >
                <?php $__errorArgs = ['jenis_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Kode Barang</label>
                <input type="text"  value="<?php echo e($item->kode_barang); ?>" class="form-control form-control-user" <?php $__errorArgs = ['kode_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="kode_barang" placeholder="kode_barang"   >
                <?php $__errorArgs = ['kode_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              

              

            <div class="form-group mb-3">
                <label class="form-control-label" for="bidang">Bidang</label>
                
                <?php $__errorArgs = ['bidang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <select id="bidang-dropdown" name="bidang" class="form-control">
                    <option value="">-- Select Bidang --</option>
                    <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <option value="<?php echo e($data->value_bidang); ?>" <?php echo e($item->bidang == $data->name ? 'selected' : ''); ?>>
                            <?php echo e($data->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group mb-3">
                <label class="form-control-label" for="kelompok">Kelompok</label>
                
                <?php $__errorArgs = ['kelompok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <select id="kelompok-dropdown" name="kelompok" class="form-control">
                    
                    <option value="">-- Select Kelompok --</option>
                    <?php $__currentLoopData = $kelompoks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <option value="<?php echo e($data->value_kelompok); ?>" <?php echo e($item->kelompok == $data->name ? 'selected' : ''); ?>>
                            <?php echo e($data->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label class="form-control-label" for="jenis">Jenis</label>
                
                <?php $__errorArgs = ['jenis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <select id="jenis-dropdown" name="jenis" class="form-control">
                    
                    <option value="">-- Select Jenis --</option>
                    <?php $__currentLoopData = $jeniss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <option value="<?php echo e($data->value_jenis); ?>" <?php echo e($item->jenis == $data->name ? 'selected' : ''); ?>>
                            <?php echo e($data->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            


              <div class="form-group">
                <label for="">Type</label>
                
                
                <select name="type" class="form-control form-control-user <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Type">
                    <option value="">-- Select Type --</option>
                    <option value="ITB Asset Item" <?php echo e($item->type == 'ITB Asset Item' ? 'selected' : ''); ?>>ITB Asset Item</option>
                    <option value="ITB Inventory Item" <?php echo e($item->type == 'ITB Inventory Item' ? 'selected' : ''); ?>>ITB Inventory Item</option>
                    <option value="ITB Expense Item" <?php echo e($item->type == 'ITB Expense Item' ? 'selected' : ''); ?>>ITB Expense Item</option>
                </select>

              </div>
              <button type="submit" class="btn btn-primary">Update</button>

            </form>
              <div class="d-flex flex-row-reverse">
                <form action="<?php echo e(route('item.destroy',['id'=>$item])); ?>" method="post" class="right">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('delete'); ?>
                  <button class="btn btn-danger" type="submit">Delete item</button>
                </form>
              </div>

          </div>

        </div>

      </div>

  </form>
</div>
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script >
    $(document).ready(function () {

        $('#bidang-dropdown').on('change', function () {
           // var idBidang = this.value;

            var bidang = $('select[name="bidang"]').val();
            $("#kelompok-dropdown").html('');
            $.ajax({
                url: "<?php echo e(route('item.fetch-kelompok')); ?>",
                type: "POST",
                data: {
                    valuee_bidang: bidang,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                // success: function (result) {
                //     $('#kelompok-dropdown').html('<option value="">-- Select Kelompok --</option>');
                //     $.each(result.kelompok, function (key, value) {
                //         // $("#kelompok-dropdown").append('<option value="' + value
                //         //     .id + '">' + value.name + '</option>');
                //             // for ($bidang as $data){
                //             //     $("#kelompok-dropdown").append('<option value="' + value.value_kelompok + '" <?php echo e($item->kelompok == $data->name); ?>>' + value.name + '</option>');
                //             // }
                //             // <option value="<?php echo e($data->value_bidang); ?>" <?php echo e($item->bidang == $data->name ? 'selected' : ''); ?>>
                //             //     <?php echo e($data->name); ?>

                //             // </option>
                //             $("#kelompok-dropdown").append('<option value="' + value.value_kelompok + '">' + value.name + '</option>');

                //         // $("#kelompok-dropdown").append('<option value="' + value.value_kelompok + '">' + value.name + '</option>');
                //         // $("#kelompok-dropdown").append('<option name="kelompok_id" value="' + value.id + '">' + value.name + '</option>');
                //     });
                //     $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
                // }
                success: function (result) {
                    $('#kelompok-dropdown').html('<option value="">-- Select Kelompok --</option>');
                    $.each(result.kelompok, function (key, value) {
                        var selected = "<?php echo e($item->kelompok); ?>" == value.name ? 'selected' : '';
                        $("#kelompok-dropdown").append('<option value="' + value.value_kelompok + '" ' + selected + '>' + value.name + '</option>');
                    });
                    $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');

                }
                // success: function (result) {
                //     $('#kelompok-dropdown').html('<option value="">-- Select Kelompok --</option>');
                //     $.each(result.kelompok, function (key, value) {
                //         var selected = "<?php echo e($item->kelompok); ?>" == value.name ? 'selected' : '';
                //         $("#kelompok-dropdown").append('<option value="' + value.value_kelompok + '" ' + selected + '>' + value.name + '</option>');
                //     });
                //     $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
                // }

            });
        });

        $('#kelompok-dropdown').on('change', function () {
            var idKelompok = this.value;
            $("#jenis-dropdown").html('');
            $.ajax({
                url: "<?php echo e(route('item.fetch-jenis')); ?>",
                type: "POST",
                data: {
                    valuee_kelompok: idKelompok,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                dataType: 'json',
                success: function (res) {
                    // $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
                    // $.each(res.jenis, function (key, value) {
                    //     $("#jenis-dropdown").append('<option value="' + value
                    //         .value_jenis + '">' + value.name + '</option>');
                    // });
                    $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
                    $.each(res.jenis, function (key, value) {
                        var selected = "<?php echo e($item->jenis); ?>" == value.name ? 'selected' : '';
                        $("#jenis-dropdown").append('<option value="' + value.value_jenis + '" ' + selected + '>' + value.name + '</option>');
                    });
                }
            });
        });
        });

        $(document).ready(function(){
        $('#selectOption').change(function(){
            var selectedOption = $(this).val();

            $.ajax({
                url: '<?php echo e(route("item.get-data")); ?>',
                type: 'POST',
                data: {
                    '_token': '<?php echo e(csrf_token()); ?>',
                    'selectedOption': selectedOption
                },
                success: function(response) {
                    // Isi kolom berikutnya dengan data yang diterima dari server
                    $('#inputAutoFill').val(response.data);
                }
            });
        });
});

//     $(document).ready(function () {
//     $('#bidang-dropdown').on('change', function () {
//         var bidang = $('select[name="bidang"]').val();
//         $("#kelompok-dropdown").html('');
//         $.ajax({
//             url: "<?php echo e(route('item.fetch-kelompok')); ?>",
//             type: "POST",
//             data: {
//                 bidang_id: bidang,
//                 _token: '<?php echo e(csrf_token()); ?>'
//             },
//             dataType: 'json',
//             success: function (result) {
//                 $('#kelompok-dropdown').html('<option value="">-- Select Kelompok --</option>');
//                 $.each(result.kelompok, function (key, value) {
//                     $("#kelompok-dropdown").append('<option value="' + value.id + '">' + value.name + '</option>');
//                 });
//                 $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
//             }
//         });
//     });

//     $('#kelompok-dropdown').on('change', function () {
//         var kelompok = $('select[name="kelompok"]').val();
//         $("#jenis-dropdown").html('');
//         $.ajax({
//             url: "<?php echo e(route('item.fetch-jenis')); ?>",
//             type: "POST",
//             data: {
//                 kelompok_id: kelompok,
//                 _token: '<?php echo e(csrf_token()); ?>'
//             },
//             dataType: 'json',
//             success: function (result) {
//                 $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
//                 $.each(result.jenis, function (key, value) {
//                     $("#jenis-dropdown").append('<option value="' + value.id + '">' + value.name + '</option>');
//                 });
//             }
//         });
//     });

//     // set selected values in dropdowns on page load
//     var bidang = $('select[name="bidang"]').val();
//     var kelompok = $('select[name="kelompok"]').val();
//     var jenis = $('select[name="jenis"]').val();
//     if (bidang) {
//         $('#bidang-dropdown').trigger('change');
//         $('#kelompok-dropdown').val(kelompok);
//     }
//     if (kelompok) {
//         $('#kelompok-dropdown').trigger('change');
//         $('#jenis-dropdown').val(jenis);
//     }
// });
</script>

<?php echo $__env->make('layouts.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-item\resources\views/item/edit.blade.php ENDPATH**/ ?>