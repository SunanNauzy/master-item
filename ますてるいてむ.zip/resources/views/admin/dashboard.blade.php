@extends('layouts.admin-panel')

@section('content')
<div style="overflow-y:scroll" class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    <form action="" id="filtersForm">
                <div class="input-group">
                <input type="text" name="from-to" class="form-control mr-2" id="date_filter">
                <span class="input-group-btn">
                    <input type="submit" class="btn btn-primary" value="Filter">
                </span>
                </div>
            </form>
  </div>


  <!-- Content Row -->

  <div style="width: 2500px; " class="row">
    <!-- Area Chart -->
    <div class="col-xl-8 col-lg-7">
      <div class="card shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
          <h6 class="m-0 font-weight-bold text-primary">Bar Chart Jumlah Pengajuan Per Bidang</h6>
        </div>
        <!-- Card Body -->
        <div class="card-body">
          <div class="chart-area">
            <canvas id="myAreaChart"></canvas>
          </div>
        </div>
    </div>
      </div>
    </div>

  <div style="width: 2500px" class="row">
    <div class="col-xl-8 col-lg-7" >
        <div class="card shadow mb-4" >
          <!-- Card Header - Dropdown -->
          <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Pie Chart Jumlah Pengajuan Per Tipe Item</h6>
          </div>
          <!-- Card Body -->
          <div class="card-body">
            <div class="chart-area">
              <canvas id="myPieChart1"></canvas>
            </div>
          </div>
      </div>
        </div>
    </div>

    <div style="width: 2500px" class="row">
        <div class="col-xl-8 col-lg-7" >
            <div class="card shadow mb-4" >
              <!-- Card Header - Dropdown -->
              <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">Pie Chart Jumlah Pengajuan Per Jenis Transaksi</h6>
              </div>
              <!-- Card Body -->
              <div class="card-body">
                <div class="chart-area">
                  <canvas id="myPieChart"></canvas>
                </div>
              </div>
          </div>
            </div>
        </div>

        <div style="width: 2500px;" class="row">
            <!-- Area Chart -->
            <div class="col-xl-8 col-lg-7">
              <div class="card shadow mb-4">
                <!-- Card Header - Dropdown -->
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Bar Chart Jumlah Pengajuan Per Unit</h6>
                </div>
                <!-- Card Body -->
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart1"></canvas>
                  </div>
                </div>
            </div>
              </div>
            </div>


            <!-- The Modal -->
            <div id="myModal" class="modal">
                <!-- Modal content -->
                <div class="modal-content">
                <span class="close">&times;</span>
                <div class="modal-body"></div>
                </div>
            </div>

</div>



{{-- <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel"></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body"></div>
        </div>
    </div>
</div> --}}

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Modal Title</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Modal content here...
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>

@endsection

{{-- <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> --}}
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/2.9.3/umd/popper.min.js" integrity="sha512-PzUUEHvq8mLGKd6UHXZpVx9IcR8PVUW47LnU/c3zUJszIcL8SgS71T87hMkGj9WrB4DyQWzTqtQU7VJHrGBtQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> --}}
{{-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha1/js/bootstrap.min.js" integrity="sha384-5oXkSWq3KEO6+FX5PxODQvZIMLgGQrHt+28EzQHEJklcYj58PbZOyDEHVEtDkA+N" crossorigin="anonymous"></script> --}}

@push('js')
<script>

var tipe = [];
var total = [];
var bidang = [];
var total1 = [];
var jenis_transaksi = [];
var total2 = [];
var unit = [];
var total3 = [];
@foreach ($totalBuyerPurchases as $totalBuyerPurchase)
    tipe.push('{{$totalBuyerPurchase->tipe}}');
    total.push('{{$totalBuyerPurchase->total}}');
@endforeach
@foreach ($totalbidang as $totalbidang)
    bidang.push('{{$totalbidang->bidang}}');
    total1.push('{{$totalbidang->total}}');
@endforeach
@foreach ($totaljtransaksi as $totaljtransaksi)
    jenis_transaksi.push('{{$totaljtransaksi->jenis_transaksi}}');
    total2.push('{{$totaljtransaksi->total}}');
@endforeach
@foreach ($totalunit as $totalunit)
    unit.push('{{$totalunit->unit}}');
    total3.push('{{$totalunit->total}}');
@endforeach

// Pie Chart Example


var ctx = document.getElementById("myPieChart");
var myPieChart = new Chart(ctx, {
  type: 'pie',
  data: {
    labels: jenis_transaksi,
    datasets: [{
      data: total2,
      backgroundColor: getRandomColor(),
      //hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
      //hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: true
    },
    //cutoutPercentage: 80,
  },
});

var ctx1 = document.getElementById("myPieChart1");
var myPieChart = new Chart(ctx1, {
  type: 'pie',
  data: {
    labels: tipe,
    datasets: [{
      data: total,
      backgroundColor: getRandomColor(),
      //hoverBackgroundColor: ['#2e59d9', '#17a673', '#2c9faf'],
      //hoverBorderColor: "rgba(234, 236, 244, 1)",
    }],
  },
  options: {
    maintainAspectRatio: false,
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
    },
    legend: {
      display: true
    },
    //cutoutPercentage: 80,
  },
});

function number_format(number, decimals, dec_point, thousands_sep) {
  // *     example: number_format(1234.56, 2, ',', ' ');
  // *     return: '1 234,56'
  number = (number + '').replace(',', '').replace(' ', '');
  var n = !isFinite(+number) ? 0 : +number,
    prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
    sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
    dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
    s = '',
    toFixedFix = function(n, prec) {
      var k = Math.pow(10, prec);
      return '' + Math.round(n * k) / k;
    };
  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || '';
    s[1] += new Array(prec - s[1].length + 1).join('0');
  }
  return s.join(dec);
}

function getRandomColor() { //generates random colours and puts them in string
  var colors = [];
  for (var i = 0; i < 50; i++) {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var x = 0; x < 6; x++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    colors.push(color);
  }
  return colors;
}

// Area Chart Example
var ctx2 = document.getElementById("myAreaChart");
var myLineChart = new Chart(ctx2, {
  type: 'bar',
  data: {
    labels: bidang,
    datasets: [{
      label: 'Total',
      //lineTension: 0.3,
      backgroundColor: getRandomColor(),
      data: total1,

    }],

  },
  options: {
    maintainAspectRatio: false,
    // layout: {
    //   padding: {
    //     left: 10,
    //     right: 25,
    //     top: 25,
    //     bottom: 0
    //   }
    // },
    scales: {
      xAxes: [{

        gridLines: {
          display: false,
          drawBorder: false
        },

      }],
      yAxes: [{
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      //titleMarginBottom: 10,
      titleFontColor: '#6e707e',
      titleFontSize: 14,
      borderColor: '#dddfeb',
      //borderWidth: 1,
      //xPadding: 15,
     // yPadding: 15,
      //displayColors: false,
      //intersect: false,
      //mode: 'index',
      //caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + ': ' + number_format(tooltipItem.yLabel);
        }
      }
    },
    onClick: function(e) {
                var activePoints = myLineChart.getElementsAtEvent(e);
                if (activePoints.length > 0) {
                    var selectedIndex = activePoints[0]._index;
                    // Tampilkan modal atau lakukan tindakan lainnya berdasarkan indeks yang dipilih
                    $('#myModal').modal('show'); // Contoh menampilkan modal menggunakan Bootstrap Modal
                }
            }

  }
});

var canvas = document.getElementById("myAreaChart1");
var ctx3 = canvas.getContext('2d');
var myLineChart = new Chart(ctx3, {
  type: 'bar',
  data: {
    labels: unit,
    datasets: [{
      label: 'Total',
      //lineTension: 0.3,
      backgroundColor: getRandomColor(),
      data: total3,

    }],

  },
  options: {
    maintainAspectRatio: false,
    scales: {
      xAxes: [{

        gridLines: {
          display: false,
          drawBorder: false
        },

      }],
      yAxes: [{
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#858796",
      //titleMarginBottom: 10,
      titleFontColor: '#6e707e',
      titleFontSize: 14,
      borderColor: '#dddfeb',
      //borderWidth: 1,
      //xPadding: 15,
     // yPadding: 15,
      //displayColors: false,
      //intersect: false,
      //mode: 'index',
      //caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + ': ' + number_format(tooltipItem.yLabel);
        }
      }
    }

  }
});

canvas.onclick = (evt) => {
//   const res = myLineChart.getElementsAtEventForMode(
//     evt,
//     'nearest',
//     { intersect: true },
//     true
//   );
//     const res = myLineChart.getElementAtEvent(evt);
//   // If didn't click on a bar, `res` will be an empty array
//   if (res.length === 0) {
//     return;
//   }
//   // Alerts "You clicked on A" if you click the "A" chart
//   alert('You clicked on ' + myLineChart.data.labels[res[0].index]);

var firstPoint = myLineChart.getElementAtEvent(evt)[0];
  if (firstPoint) {
    var label = myLineChart.data.labels[firstPoint._index];
    var value = myLineChart.data.datasets[firstPoint._datasetIndex].data[firstPoint._index];

    alert('Label: ' + label + "\nValue: " + value);
  }
};

// canvas.onclick = (evt) => {
//     var activeBars = myLineChart.getElementsAtEvent(evt);
//     if (activeBars.length > 0) {
//         // Get the chart data
//         var chartData = activeBars[0]['_chart'].config.data;
//         // Get the index of the clicked bar
//         var idx = activeBars[0]['_index'];
//         // Get the label for the x-axis
//         var label = chartData.labels[idx];
//         // Get the value for the y-axis
//         var value = chartData.datasets[0].data[idx];

//         // Call a function to display the modal
//         displayModal(label, value);
//     }
// }

// chart.js

// function displayModal(label, value) {
//     // Get the modal element
//     var modal = $('#myModal');

//     // Set the modal title and body content
//     modal.find('.modal-title').text(label);
//     modal.find('.modal-body').text(value);

//     // Display the modal
//     modal.modal('show');
// }

// canvas.onclick = function(evt) {
//     var points = myLineChart.getBarsAtEvent(evt);
//     var value = myLineChart.datasets[0].points.indexOf(points[0]);
//     if(value == 5){
//       $('#myModal').modal('show');
//     } else if(value == 4){
//       $('#myModal1').modal('show');
//     }
//   };



//var canvas = document.getElementById('myAreaChart1');
// var modal = document.getElementById('myModal');
// var span = document.getElementsByClassName('close')[0];

// canvas.onclick = function(event) {
//     // var activePoints = myLineChart.getElementsAtEvent(event);
//     var activePoints = myLineChart.getElementsAtEventForMode(event, 'nearest', { intersect: true });
//     var firstPoint = activePoints[0];
//     var label = myLineChart.data.labels[firstPoint._index];
//     var value = myLineChart.data.datasets[firstPoint._datasetIndex].data[firstPoint._index];
//     var modalBody = document.getElementById('modal-body');
//     modalBody.innerHTML = '<p>Label: '+label+'</p><p>Value: '+value+'</p>';
//     modal.style.display = 'block';
// }

// span.onclick = function() {
//     modal.style.display = 'none';
// }

// window.onclick = function(event) {
//     if(event.target == modal) {
//         modal.style.display = 'none';
//     }
// }



// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#858796';

function number_format(number, decimals, dec_point, thousands_sep) {
  // *     example: number_format(1234.56, 2, ',', ' ');
  // *     return: '1 234,56'
  number = (number + '').replace(',', '').replace(' ', '');
  var n = !isFinite(+number) ? 0 : +number,
    prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
    sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
    dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
    s = '',
    toFixedFix = function(n, prec) {
      var k = Math.pow(10, prec);
      return '' + Math.round(n * k) / k;
    };
  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || '';
    s[1] += new Array(prec - s[1].length + 1).join('0');
  }
  return s.join(dec);
}

    $(function () {
  let searchParams = new URLSearchParams(window.location.search)
  let dateInterval = searchParams.get('from-to');
  let start = moment().subtract(29, 'days');
  let end = moment();

  if (dateInterval) {
      dateInterval = dateInterval.split(' - ');
      start = dateInterval[0];
      end = dateInterval[1];
  }

  $('#date_filter').daterangepicker({
      "showDropdowns": true,
      "showWeekNumbers": true,
      "alwaysShowCalendars": true,
      startDate: start,
      endDate: end,
      locale: {
          format: 'YYYY-MM-DD',
          firstDay: 1,
      },
      ranges: {
          'Today': [moment(), moment()],
          'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days': [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month': [moment().startOf('month'), moment().endOf('month')],
          'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
          'This Year': [moment().startOf('year'), moment().endOf('year')],
          'Last Year': [moment().subtract(1, 'year').startOf('year'), moment().subtract(1, 'year').endOf('year')],
          'All time': [moment().subtract(30, 'year').startOf('month'), moment().endOf('month')],
      }
  });

  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)

  let dtOverrideGlobals = {
    buttons: dtButtons,
    processing: true,
    serverSide: true,
    retrieve: true,
    aaSorting: [],
    ajax: {
      url: "{{ route('admin.dashboard') }}",
      data: {
        'from-to': searchParams.get('from-to'),
      }
    },
  };
  $('.datatable-Transaction').DataTable(dtOverrideGlobals);
    $('a[data-toggle="tab"]').on('shown.bs.tab', function(e){
        $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
    });
});







</script>






@endpush


