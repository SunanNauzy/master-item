@extends('layouts.admin-panel')
@section('content')
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Adding a new Item</h1>
  <form action="{{route('item.store')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <div class="row">

      <div class="col-lg-6">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Enter the Item details</h6>
          </div>
          <div class="card-body">
            @if($errors->any())
              <div class="alert alert-danger">
                {{ implode('', $errors->all(':message')) }}
              </div>
            @endif
              <div class="form-group">
                <label for="">Name of the PIC</label>
                <input type="text" class="form-control form-control-user" @error('name') is-invalid @enderror value="{{old('bus_name')}}"  name="name" placeholder="Enter name ..."   autocomplete="name" autofocus>
                @error('name')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Jumlah Pengajuan</label>
                <input type="number" class="form-control form-control-user" @error('qty') is-invalid @enderror value="{{old('qty')}}"  name="qty" placeholder="qty ..."  >
                @error('qty')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Tanggal</label>
                <input type="date" class="form-control form-control-user" @error('input_date') is-invalid @enderror value="{{old('input_date')}}"  name="input_date" placeholder="tanggal"   >
                @error('input_date')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Approval Status</label>
                <input type="text" class="form-control form-control-user" @error('approval_status') is-invalid @enderror  name="approval_status" value="{{old('approval_status')}}" placeholder="approval_status"   >
                @error('approval_status')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

            </div>

            <hr>

            <div class="card-body">
            {{-- <p class="text-primary">Additional details</p> --}}
              <div class="form-group">
                <label for="">User</label>
                <input type="text" class="form-control form-control-user" @error('user') is-invalid @enderror  name="user" value="{{old('user')}}" placeholder="user"   >
                @error('user')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Unit</label>
                <input type="text" class="form-control form-control-user" @error('unit') is-invalid @enderror  name="unit" placeholder="unit" value="{{old('unit')}}"   >
                @error('unit')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Tipe</label>
                <input type="text" class="form-control form-control-user" @error('tipe') is-invalid @enderror  name="tipe" placeholder="tipe" value="{{old('tipe')}}"   >
                @error('tipe')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Jenis Transaksi</label>
                <input type="text" class="form-control form-control-user" @error('jenis_transaksi') is-invalid @enderror  name="jenis_transaksi" placeholder="jenis_transaksi" value="{{old('jenis_transaksi')}}"   >
                @error('jenis_transaksi')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              {{-- <div class="form-group">
                <label for="">Bidang</label>
                <input type="text" class="form-control form-control-user" @error('bidang') is-invalid @enderror  name="bidang" placeholder="bidang" value="{{old('bidang')}}"   >
                @error('bidang')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Kelompok</label>
                <input type="text" class="form-control form-control-user" @error('kelompok') is-invalid @enderror  name="kelompok" placeholder="kelompok" value="{{old('kelompok')}}"   >
                @error('kelompok')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Jenis</label>
                <input type="text" class="form-control form-control-user" @error('jenis') is-invalid @enderror  name="jenis" placeholder="jenis" value="{{old('jenis')}}"   >
                @error('jenis')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div> --}}

              <div class="form-group mb-3">
                <label class="form-control-label" for="bidang">Country</label>
                <select  id="bidang-dropdown" name="bidang" class="form-control">
                    <option value="">-- Select Bidang --</option>
                    @foreach ($bidang as $data)
                        <option value="{{$data->name}}">
                            {{$data->name}}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="form-group mb-3">
                <label class="form-control-label" for="kelompok">Kelompok</label>
                <select id="kelompok-dropdown" name="kelompok" class="form-control">
                </select>
            </div>
            <div class="form-group">
                <label class="form-control-label" for="jenis">Jenis</label>
                <select id="jenis-dropdown" name="jenis" class="form-control">
                </select>
            </div>

              <div class="form-group">
                <label for="">Type</label>
                <input type="text" class="form-control form-control-user" @error('type') is-invalid @enderror  name="type" placeholder="type" value="{{old('type')}}"   >
                @error('type')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Bulan</label>
                <input type="text" class="form-control form-control-user" @error('bulan') is-invalid @enderror  name="bulan" placeholder="bulan" value="{{old('bulan')}}"   >
                @error('bulan')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <div class="form-group">
                <label for="">Kode Barang</label>
                <input type="text" class="form-control form-control-user" @error('kode_barang') is-invalid @enderror  name="kode_barang" placeholder="kode_barang" value="{{old('kode_barang')}}"   >
                @error('kode_barang')
                  <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                  </span>
                @enderror
              </div>

              <button type="submit" class="btn btn-primary">Add</button>

          </div>
        </div>
      </div>


    </div>
  </form>
</div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    $(document).ready(function () {

        $('#bidang-dropdown').on('change', function () {
            var idBidang = this.value;
            $("#kelompok-dropdown").html('');
            $.ajax({
                url: "{{ route('item.fetch-kelompok') }}",
                type: "POST",
                data: {
                    bidang_id: idBidang,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (result) {
                    $('#kelompok-dropdown').html('<option value="">-- Select Kelompok --</option>');
                    $.each(result.kelompok, function (key, value) {
                        $("#kelompok-dropdown").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                    $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
                }
            });
        });

        $('#kelompok-dropdown').on('change', function () {
            var idKelompok = this.value;
            $("#jenis-dropdown").html('');
            $.ajax({
                url: "{{ route('item.fetch-jenis') }}",
                type: "POST",
                data: {
                    kelompok_id: idKelompok,
                    _token: '{{csrf_token()}}'
                },
                dataType: 'json',
                success: function (res) {
                    $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
                    $.each(res.jenis, function (key, value) {
                        $("#jenis-dropdown").append('<option value="' + value
                            .id + '">' + value.name + '</option>');
                    });
                }
            });
        });
        });

    // $(document).ready(function () {
    //     $('#bidang-dropdown').on('change', function () {
    //         var bidang_id = $(this).text();
    //         if (bidang_id) {
    //             $.ajax({
    //                 url: "{{ route('item.fetch-kelompok') }}" + encodeURI(bidang_id),
    //                 type: 'GET',
    //                 dataType: 'json',
    //                 success: function (data) {
    //                     $('#kelompok-dropdown').empty();
    //                     $('#kelompok-dropdown').append($('<option>').text('-- Select Kelompok --').attr('value', ''));
    //                     $.each(data, function (key, value) {
    //                         $('#kelompok-dropdown').append($('<option>').text(value.name).attr('value', value.id));
    //                     });
    //                     $('#kelompok-dropdown').prop('disabled', false);
    //                 }
    //             });
    //         } else {
    //             $('#kelompok-dropdown').empty();
    //             $('#kelompok-dropdown').append($('<option>').text('-- Select Kelompok --').attr('value', ''));
    //             $('#kelompok-dropdown').prop('disabled', true);
    //         }
    //     });
    // });
</script>

