<?php $__env->startSection('content'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800">Adding a new Item</h1>
  <form action="<?php echo e(route('item.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="row">

      <div class="col-lg-6">
        <div class="card shadow mb-4">
          <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Enter the Item details</h6>
          </div>
          <div class="card-body">
            <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                <?php echo e(implode('', $errors->all(':message'))); ?>

              </div>
            <?php endif; ?>
              <div class="form-group">
                <label for="">Name of the PIC</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(old('bus_name')); ?>"  name="name" placeholder="Enter name ..."   autocomplete="name" autofocus>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Jumlah Pengajuan</label>
                <input type="number" class="form-control form-control-user" <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(old('qty')); ?>"  name="qty" placeholder="qty ..."  >
                <?php $__errorArgs = ['qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Tanggal</label>
                <input type="date" class="form-control form-control-user" <?php $__errorArgs = ['input_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="<?php echo e(old('input_date')); ?>"  name="input_date" placeholder="tanggal"   >
                <?php $__errorArgs = ['input_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Approval Status</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['approval_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="approval_status" value="<?php echo e(old('approval_status')); ?>" placeholder="approval_status"   >
                <?php $__errorArgs = ['approval_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

            </div>

            <hr>

            <div class="card-body">
            
              <div class="form-group">
                <label for="">User</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="user" value="<?php echo e(old('user')); ?>" placeholder="user"   >
                <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Unit</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="unit" placeholder="unit" value="<?php echo e(old('unit')); ?>"   >
                <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Tipe</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="tipe" placeholder="tipe" value="<?php echo e(old('tipe')); ?>"   >
                <?php $__errorArgs = ['tipe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Jenis Transaksi</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['jenis_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="jenis_transaksi" placeholder="jenis_transaksi" value="<?php echo e(old('jenis_transaksi')); ?>"   >
                <?php $__errorArgs = ['jenis_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              

              <div class="form-group mb-3">
                <label class="form-control-label" for="bidang">Country</label>
                <select  id="bidang-dropdown" name="bidang" class="form-control">
                    <option value="">-- Select Bidang --</option>
                    <?php $__currentLoopData = $bidang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($data->name); ?>">
                            <?php echo e($data->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group mb-3">
                <label class="form-control-label" for="kelompok">Kelompok</label>
                <select id="kelompok-dropdown" name="kelompok" class="form-control">
                </select>
            </div>
            <div class="form-group">
                <label class="form-control-label" for="jenis">Jenis</label>
                <select id="jenis-dropdown" name="jenis" class="form-control">
                </select>
            </div>

              <div class="form-group">
                <label for="">Type</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="type" placeholder="type" value="<?php echo e(old('type')); ?>"   >
                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Bulan</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="bulan" placeholder="bulan" value="<?php echo e(old('bulan')); ?>"   >
                <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="form-group">
                <label for="">Kode Barang</label>
                <input type="text" class="form-control form-control-user" <?php $__errorArgs = ['kode_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  name="kode_barang" placeholder="kode_barang" value="<?php echo e(old('kode_barang')); ?>"   >
                <?php $__errorArgs = ['kode_barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <button type="submit" class="btn btn-primary">Add</button>

          </div>
        </div>
      </div>


    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
    // $(document).ready(function () {

    //     $('#bidang-dropdown').on('change', function () {
    //         var idBidang = this.value;
    //         $("#kelompok-dropdown").html('');
    //         $.ajax({
    //             url: "<?php echo e(route('item.fetch-kelompok')); ?>",
    //             type: "POST",
    //             data: {
    //                 bidang_id: idBidang,
    //                 _token: '<?php echo e(csrf_token()); ?>'
    //             },
    //             dataType: 'json',
    //             success: function (result) {
    //                 $('#kelompok-dropdown').html('<option value="">-- Select Kelompok --</option>');
    //                 $.each(result.kelompok, function (key, value) {
    //                     $("#kelompok-dropdown").append('<option value="' + value
    //                         .id + '">' + value.name + '</option>');
    //                 });
    //                 $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
    //             }
    //         });
    //     });

    //     $('#kelompok-dropdown').on('change', function () {
    //         var idKelompok = this.value;
    //         $("#jenis-dropdown").html('');
    //         $.ajax({
    //             url: "<?php echo e(route('item.fetch-jenis')); ?>",
    //             type: "POST",
    //             data: {
    //                 kelompok_id: idKelompok,
    //                 _token: '<?php echo e(csrf_token()); ?>'
    //             },
    //             dataType: 'json',
    //             success: function (res) {
    //                 $('#jenis-dropdown').html('<option value="">-- Select Jenis --</option>');
    //                 $.each(res.jenis, function (key, value) {
    //                     $("#jenis-dropdown").append('<option value="' + value
    //                         .id + '">' + value.name + '</option>');
    //                 });
    //             }
    //         });
    //     });
    //     });

    $(document).ready(function () {
        $('#bidang-dropdown').on('change', function () {
            var bidang_id = $(this).text();
            if (bidang_id) {
                $.ajax({
                    url: "<?php echo e(route('item.fetch-kelompok')); ?>" + encodeURI(bidang_id),
                    type: 'GET',
                    dataType: 'json',
                    success: function (data) {
                        $('#kelompok-dropdown').empty();
                        $('#kelompok-dropdown').append($('<option>').text('-- Select Kelompok --').attr('value', ''));
                        $.each(data, function (key, value) {
                            $('#kelompok-dropdown').append($('<option>').text(value.name).attr('value', value.id));
                        });
                        $('#kelompok-dropdown').prop('disabled', false);
                    }
                });
            } else {
                $('#kelompok-dropdown').empty();
                $('#kelompok-dropdown').append($('<option>').text('-- Select Kelompok --').attr('value', ''));
                $('#kelompok-dropdown').prop('disabled', true);
            }
        });
    });
</script>


<?php echo $__env->make('layouts.admin-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\master-item\resources\views/item/create.blade.php ENDPATH**/ ?>